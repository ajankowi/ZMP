#ifndef PORT_HH
#define PORT_HH

/*!
 * \brief Port poprzez kt�ry realizowana jest komunikacja z klientem
 *
 * Porzez ten port realizowana jest komunikacja z zewn�trzn�
 * aplikacj� klienta.
 */
#define PORT 6219

#endif
