#ifndef GSV_VECTOR3I_HH
#define GSV_VECTOR3I_HH


#include "geomVector.hh"


namespace gsv {


  typedef geom::Vector<int,3>   Vector3i;

}



#endif
